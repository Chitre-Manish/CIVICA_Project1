﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIVICA_Project1
{
    class RectangeArea
    {

        static void Main(string[] args)
        {
           
            Rectangle recobj = new Rectangle();

            recobj.setLength(5);
            recobj.setWidth(10);
            recobj.setCost(25);
            int area = recobj.getarea();

            //recobj.getCost(area);
            

            // int len1 = shpobj.length;

            // int breath = shpobj.width;
            //int areaCal =  shpobj.area(len1,breath);
         

           Console.WriteLine("The total area -> " + recobj.length + " & " + recobj.width + " is " + area + " Sq ft ");
            Console.WriteLine("Paint Cost per sq feet -> " + recobj.paintCost);
            Console.WriteLine("Total paint cost is " + area + " * " + recobj.paintCost + " = " + recobj.getCost(area));

            Console.ReadLine();

        }
    }
}
