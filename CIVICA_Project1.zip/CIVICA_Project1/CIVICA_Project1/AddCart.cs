﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIVICA_Project1 //Derived class (child class - 2)
{
    class AddCart : Search
    {

        public override void print()
        {
            Console.WriteLine("This is a child class - AddCart");
        }
    }
}
