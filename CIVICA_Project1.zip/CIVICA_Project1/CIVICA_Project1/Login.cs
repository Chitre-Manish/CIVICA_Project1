﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIVICA_Project1
{
    class Login //Parent class//
    {
        public string userName = "Rahul";

        public void credential()
        {
            Console.WriteLine(" Users details -");
        }

        public virtual void print()
        {
            Console.WriteLine("This is a parent class login");     
        }


    }
}
