﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIVICA_Project1
{
    class Calculation : InheritInterface
    {

        public int getArea()
        {
            return (wid * len);
        }


        public int getPaintCost(int a)
        {
            return (cost * a);
        }
    }
}
