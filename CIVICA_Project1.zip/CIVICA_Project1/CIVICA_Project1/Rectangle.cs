﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIVICA_Project1
{
    class Rectangle : Shap
    {

       
        //public int totalArea;
        //public int wid;


        public int getarea()
        {
            return (length *width);
            
        }

        public int getCost(int totalArea)
        {
            return (paintCost * totalArea);
        }
    }
}
