﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Humanizer;

namespace CIVICA_Project1
{
    class nugetexample
    {

        static void Main(string[] args)
        {
            Console.WriteLine(TimeSpan.FromMilliseconds(1299630020).Humanize(3));
            Console.WriteLine(TimeSpan.FromMilliseconds(7566345).Humanize(2));
            Console.WriteLine(TimeSpan.FromMilliseconds(1235665778).Humanize(4));

            Console.ReadLine();
        }

    }
}
