﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIVICA_Project1
{
    class Program
    {
        static void Main(string[] args)
        {
            // These codes are just to print the line in console window //

            Console.WriteLine("Welcome to the selenium Testing");
            Console.WriteLine("This is Csharp session");
            Console.WriteLine("Day 1 session");

            string name = "Rahul is the trainer for selenium";
            Console.WriteLine(name);

            // DataTypes//

            int salaryMonthly = 2000; // Integer (Whole Number) - 4 bytes -> Stores whole number from -2,147,483,648 to 2,147,483,648
            double salaryAnnually = 4000.56; //Floating number - Decimal number
            char letter = 'R';
            bool condition = true;

            Console.WriteLine(salaryMonthly);
            Console.WriteLine(salaryAnnually);
            Console.WriteLine(letter);
            Console.WriteLine(condition);

            /* Arithmetic Operaters -> +, -, *, /, %, ++, --,
               Assignment Operators -> ==, ??=
               Comparison Operators  -> <, >, <=, >=, ==, !=
               Boolean Operators -> !, &&, ||
               Betwise Operators  ->  ~     
            */

            int firstNum = 20;
            int secondNum = 30;
            int sum = firstNum + secondNum;
                          
            Console.WriteLine(sum);
            Console.WriteLine("Total sum is -> " + sum);

            Console.WriteLine(Math.Sqrt(64));
            Console.WriteLine(Math.Min(firstNum,secondNum));
            Console.WriteLine(Math.Round(1.5));

            // If Conditions //

            int age = 6;

            if (age > 20)
            {
                Console.WriteLine("Person is eligible for PM seat");
            }
            else if (age > 9)
            {

                Console.WriteLine("wait for 1 year");
            }
            else if (age > 5)
            {
                Console.WriteLine("Sorry wait for few more years");
            }
            else
            {
                Console.WriteLine("Wait untill you get matured");
            }

            //Switch//

            int customerOption = 6;

            switch (customerOption)
            {
                case 1:
                    Console.WriteLine("You have selected the language changes");
                    break;
                case 2:
                    Console.WriteLine("You have selected the Credit card Bill summary");
                    break;
                case 3:
                    Console.WriteLine("You have selected credit card block option");
                    break;
                case 4:
                    Console.WriteLine("You have selected to speak to customer agent");
                    break;
                case 5:
                    Console.WriteLine("You have to selected the option to listen again");
                    break;
                default:
                    Console.WriteLine("You have selected an Invaild option");
                    break;
            }

            // For loop //

            for(int i=0; i<5; i++)
            {
                Console.WriteLine(i);
            }

            // while loop

            int j = 0;
            while (j<5)
            {
                Console.WriteLine(j);
                j++;
            }

            // Do while loop

            int k = 0;
            do
            {
                Console.WriteLine(k);
                k++;

            } while (k < 5);

            // Small Assignment //
            string firstName = "Manish";
            string middleName = "Pradip";
            string lastName = "Chitre";
            string fullName = firstName + " " + middleName + " " + lastName;
            Console.WriteLine(fullName);

            // Taking input from user//

            Console.WriteLine("Enter the User Name ->");
            string userName = Console.ReadLine();
            Console.WriteLine("User name is " + userName);

            // Array //

            string[] empName = { "Alex", "Phil", "Mark", "Jack" };
            // Console.WriteLine(empName[2]);
            Console.WriteLine(empName.Length);
            empName[0] = "Alan";

            Array.Sort(empName);

            foreach (string y in empName)
            {
                Console.WriteLine(y);           
            }


           /* for(int x =0; x<empName.Length; x++)
                Console.WriteLine(empName[x]); */




            Console.ReadLine();
        }
    }
}
