﻿using System; 
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIVICA_Project1
{
    class Employeedetails
    {
        string empName = "Rahul"; // declaration of variable of type string
        int empsalary = 3456;  // declaration of variable of type int

        string empAdd;
        int mobileNo;

        public string empCompanyname;

        /* public Employeedetails() // Constructor//
         {
             empCompanyname = "CIVICA";
         } */

        public Employeedetails(string companyName) // parametrized constructor//
        {
            empCompanyname = companyName;
        
        }



        static void Main(string[] args) // Main Method
        {
            Employeedetails obj = new Employeedetails("CIVICA");
            Console.WriteLine(obj.empName);
            Console.WriteLine(obj.empsalary);

            obj.empAdd = "Chennai";
            string x = obj.empAdd;
            obj.mobileNo = 98660;
            Console.WriteLine(x);
            Console.WriteLine(obj.mobileNo);

            Employeedetails obj1 = new Employeedetails("CIVICA2");
            obj1.empAdd = "Mumbai";
            obj1.mobileNo = 14764;
            Console.WriteLine(obj1.empAdd);
            Console.WriteLine(obj1.mobileNo);

            Console.WriteLine(obj.empCompanyname); // value from constructor//
            Console.WriteLine(obj1.empCompanyname); // value from constructor//



            Console.ReadLine();
        }







    }
}
