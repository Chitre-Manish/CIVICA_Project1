﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIVICA_Project1
{
    class Shap
    {
        public int length;
        public int width;
        public int paintCost;

        public void setLength(int len)
        {
            length = len;
        }

        public void setWidth(int wid)
        {
            width = wid;        
        }

        public void setCost(int paintRate)
        {
            paintCost = paintRate;
        }

    }
}
