﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIVICA_Project1
{
    class MethodExample
    {
        static void MethodX()
        {
            Console.WriteLine("I am running the method outside the main");
        }

        static void MethodY(string trainingName)
        {
            Console.WriteLine("I am do training on " + trainingName);
        }

        static int MethodAdd(int x, int y)
        {
            return x + y;
        }

        static double MethodAdd(double x, double y)
        {
            return x + y;
        }

        static void Main(string[] args)
        {
            MethodX();
            //string topic = "selenium";
            MethodY("selenium");

            int sum = MethodAdd(20, 30); // Method overloading - Same method name but different datatype or different arguments//
            Console.WriteLine(sum);

            Console.WriteLine(MethodAdd(2.6,7.8)); // Method overloading - Same method name but different datatype or different arguments //


            // creating an object for the class ChildClass//

            ChildClass myObj = new ChildClass();
            Console.WriteLine(myObj.empName);


            myObj.empAddress = "Pune";
            myObj.mobilNo = 1234;

            ChildClass myObj1 = new ChildClass();

            myObj1.empAddress = "Banglore";
            myObj1.mobilNo = 98765;


            Console.WriteLine(myObj.empAddress);
            Console.WriteLine(myObj1.empAddress);

            myObj.empDetails();

            // Expection handeling//

           try
            {
                int[] num = { 1, 4, 7 };
                Console.WriteLine(num[5]);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            
            Console.ReadLine();
        }






    }
}
