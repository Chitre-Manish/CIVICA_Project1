﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIVICA_Project1
{
    class RetailMainApp
    {
        static void Main(string[] args)
        {
            Search obj = new Search();
            obj.credential();
            Console.WriteLine(obj.userName + " ---- " + obj.searchItem);
            // Console.WriteLine(obj.searchItem);

            //obj.print();

            //Login logobj = new Login();
            //Search srcobj = new Search();
            //AddCart addobj = new AddCart();


            Login logobj = new Login();
            Login srcobj = new Search();
            Search addobj = new AddCart();

            logobj.print();
            srcobj.print();
            addobj.print();



            Console.ReadLine();
        
        }
    }
}
