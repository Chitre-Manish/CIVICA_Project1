﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIVICA_Project1
{
    class Class1
    {
        static void Main(string[] args)
        {
            Calculation obj = new Calculation();
            obj.setwidth(7);
            obj.setLength(10);
            obj.setpaintCost(30);

            int area = obj.getArea();

            //obj.getPaintCost(area);

            Console.WriteLine("The total area is " + obj.wid + " * " + obj.len + " = " + obj.getArea());
            Console.WriteLine("The paint cost per sq feet is " + obj.cost);
            Console.WriteLine("The total paint cost for area " + obj.getArea() + " sq ft is " + obj.getArea() + " * " + obj.cost + " = " + obj.getPaintCost(area)); 
            Console.ReadLine();
        
        }
    }
}
