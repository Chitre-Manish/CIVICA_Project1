﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIVICA_Project1
{
    interface Istudent
    {
        void studentactivity(); // interface method - does not have any body
    }

    class primarystudent : Istudent
    {
        public void studentactivity()
        {
            Console.WriteLine("Primary section plays more");        
        }
    }
    class exampleInterface
    {
        static void Main(string[] args)
        {
            primarystudent obj = new primarystudent();
            obj.studentactivity();

            Console.ReadLine();
        }
    }
}
