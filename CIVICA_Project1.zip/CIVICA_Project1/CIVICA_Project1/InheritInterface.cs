﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIVICA_Project1
{
    interface ILength
    {
        void setLength(int l);
        void setpaintCost(int c);
    }

    interface IWidth : ILength
    {
        void setwidth(int w);
    }


    class InheritInterface : IWidth
    {
       public int wid;
       public int len;
       public int cost;

       public void setwidth(int w)
        {
            wid = w;
           
        }

        public void setLength(int l)
        {
            len = l;
        }

        public void setpaintCost(int c)
        {
            cost = c;
            
        }
    }
}
