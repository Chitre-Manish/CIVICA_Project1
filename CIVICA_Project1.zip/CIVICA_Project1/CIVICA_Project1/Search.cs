﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIVICA_Project1
{
    class Search : Login  //Derived class (child class - 1)
    {

        public string searchItem = "MobilePhone";

        public override void print()
        {
            Console.WriteLine(" This is the child class - search");
        }

    }

   
}
