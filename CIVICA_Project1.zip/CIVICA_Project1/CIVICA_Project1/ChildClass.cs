﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CIVICA_Project1
{
    class ChildClass
    {
        public string empName = "Alex";

        public string empAddress;
        public int mobilNo;

        public void empDetails()
        {

            Console.WriteLine("this is emp details");
        }
    }
}
